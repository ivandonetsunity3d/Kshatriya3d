﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class FirstMenu : MonoBehaviour {
	SaveLoadManager loadmanager;

	public string LoadFilePath;

	// Use this for initialization
	void Start () 
	{
		loadmanager=transform.GetComponent<SaveLoadManager> ();
		LoadFilePath=Application.persistentDataPath + "/";
	}


	public void StartNewGame()
	{
		//Application.LoadLevel ("01 Level 1");
		SceneManager.LoadScene ("01 Level 1");

	}

	public void LoadLastGamePressed()
	{
		loadmanager.LoadFile (LoadFilePath);

	}




}
