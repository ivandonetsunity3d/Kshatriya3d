﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TextTo3d : MonoBehaviour {

	public Transform camera;


	public InputField NounField;
	public Transform nounTransform;


	public InputField VerbField;
	public InputField Noun2Field;


  //  public Transform VerbTextField;
   // public Transform NounTextField;
	//public Transform Noun2TextField;

 //   public Transform SelectedNoun;


    public string noun;
    public string verb;
    public string noun2;

    public AnimatorScript NounScript;

    public Vector3 Noun2Position;




    public GameObject Noun;
    public GameObject Noun2;


	DiabloCameraController CameraScript;

	// Use this for initialization
	void Start () 
	{
		CameraScript=camera.GetComponent<DiabloCameraController > ();	
	}

    public void NounEntered() 
    {
        noun = NounField.text;

        if (noun != "") 
        {
            Noun = GameObject.Find(noun.ToUpper());
            if (Noun != null)
            {
                CameraScript.player = Noun;
            }        
        }
    }

    public void ClearNoun()
    {
		NounField.text = "";
        //UnityEngine.UI.Text txt = SelectedNoun.GetComponent<Text>();
        //txt.text = "";

        // txt = NounField;
        //txt.text = "";

    }


    void Update() 
    {
		//LeftClick
        if (Input.GetMouseButtonUp(0)) 
        {
            noun = NounField.text;            

            if (noun != "")
             {
				Noun = GameObject.Find(noun);
				CameraScript.player = Noun;
                NounIsNotEmptyLeftClick();
             }
            else if (noun == "") 
            {
				NounIsEmptyLeftClick();                               
            }
        }

		//RightClick
        else if (Input.GetMouseButtonUp(1))
        {
         noun = NounField.text;

         if (noun != "")
         {
             NounIsNotEmptyRightClick();
         }
         else if (noun == "")
         {
            // UnityEngine.UI.Text txt = SelectedNoun.GetComponent<Text>();            
				if (NounField.text != "") 
             {
					noun = NounField.text;
                 Noun = GameObject.Find(noun);
                 NounIsNotEmptyRightClick();
             }                       
         }
        }
    }



	void NounIsEmptyLeftClick() 
    {
		ClearNoun();

        Transform noun1transform = GetClickTransform();
        if (noun1transform != null)
        {
            Debug.Log(noun1transform.name);
            Noun = noun1transform.gameObject;

            //UnityEngine.UI.Text txt = SelectedNoun.GetComponent<Text>();

			NounField.text = noun1transform.name;

			CameraScript.player =GameObject.Find( NounField.text);
            //NounScript.AttackTransform(verb, noun2transform);
        } 
    }

    void NounIsNotEmptyRightClick()
    {
        Noun = GameObject.Find(noun.ToUpper());
        CameraScript.player = Noun;

        verb = "attacks";

        NounScript = Noun.GetComponent<AnimatorScript>();

        Transform noun2transform = GetClickTransform();
		if (noun2transform != null) {
			Debug.Log (noun + ", " + verb + ", " + noun2transform.name);

			noun2 = noun2transform.name.ToUpper ();

			if (noun.ToUpper () != noun2) {
				NounScript.AttackTransform (verb, noun2transform);
			}          
		} else if (noun2transform == null) 
		{
			// just copied from NounIsNotEmptyLeftClick
			Noun = GameObject.Find(noun.ToUpper());
			CameraScript.player = Noun;

			verb = "walks to";

			NounScript = Noun.GetComponent<AnimatorScript>();

			Vector3 pos = GetClickPoint();
			if (pos != Vector3.zero)
			{
				//NounField.text

				NounScript.ApproachAndAttack = false;
				NounScript.IsAttacking = false;
				NounScript.Goto(verb, pos);
			}
			else 
			{
				ClearNoun();
			}

		}
    }


    void NounIsNotEmptyLeftClick() 
    {
		Noun = GameObject.Find(noun.ToUpper());
		CameraScript.player = Noun;

		//verb = "is idle";

		NounScript = Noun.GetComponent<AnimatorScript>();

		nounTransform = GetClickTransform();
		if (nounTransform != null) {
			noun = nounTransform.name.ToUpper ();
			NounField.text = noun;

			Debug.Log (noun + " selected");			       
		} else if (nounTransform == null) 
		{
			//
			Noun = GameObject.Find(noun.ToUpper());
			CameraScript.player = Noun;

			verb = "walks to";

			NounScript = Noun.GetComponent<AnimatorScript>();

			Vector3 pos = GetClickPoint();
			if (pos != Vector3.zero)
			{
				//NounField.text

				NounScript.ApproachAndAttack = false;
				NounScript.IsAttacking = false;
				NounScript.Goto(verb, pos);
			}
			else 
			{
				ClearNoun();
			}

		}


    }



    Transform GetClickTransform() 
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		RaycastHit[] hits = Physics.RaycastAll (ray);

        foreach (RaycastHit hit in hits)
        {
            if (hit.transform.name != "Terrain") 
            {
                return hit.transform;
            }        
        }

        return null;
    }


    Vector3 GetClickPoint() 
    {
        Plane playerPlane = new Plane(Vector3.up, Noun.transform.position);
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        float hitdist = 0.0f;

        if (playerPlane.Raycast(ray, out hitdist))
        {            
            Noun2Position = ray.GetPoint(hitdist);
			Noun2Position.y = 0;
            return Noun2Position;
        }

        return Vector3.zero;
    }

    

    public void Execute()
    {
        // noun = NounTextField.GetComponent<Text>().text;
         //verb = VerbTextField.GetComponent<Text>().text;
		 //noun2 = Noun2TextField.GetComponent<Text>().text;

		noun = NounField.text;
		verb = VerbField.text;
		noun2 = Noun2Field.text;


         Noun = GameObject.Find(noun.ToUpper());
         CameraScript.player = Noun;

         if (noun != noun2) 
         {
             Debug.Log(noun + ", " + verb + ", " + noun2);
                          
             //Noun.SetActive(true);

             Noun2 = GameObject.Find(noun.ToUpper());
             Noun2.GetComponent<NavMeshAgent>().enabled = false;
             Noun2.GetComponent<NavMeshObstacle>().enabled = true;

          // Noun2.SetActive(true);
                         
             Noun.GetComponent<AnimatorScript>().Play(verb, noun2);
         }

		

    }


}
