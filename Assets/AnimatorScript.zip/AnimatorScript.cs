﻿using UnityEngine;
using System.Collections;

public enum CreatureKind
{
	human,
	animal,
	bird,
    humanoid
}

public class AnimatorScript : MonoBehaviour {

  	public  Animator animator;
  	public int layer;
	public CreatureKind creaturekind;

	public Transform AgentTransform, EnemyTransform;
	NavMeshAgent agent;
	NavMeshObstacle obstacle;

	public Vector3 destinationPosition;			// The destination Point
	public float destinationDistance;			// The distance between myTransform and destinationPosition

	public GameObject Noun2go ;
    public string noun2;
    public string verb;

	public AnimatorScript Noun2Script;


    public string DestinationVerb;
    public bool ApproachAndAttack = false;
    public bool IsAttacking = false;

    public bool WalkingToPoint = false;

	public int maxhealth = 100;
	public int health;
	public bool alive = true; //attack only those noun2, if their (alive state is == true) or stop attack


    // Use this for initialization
    void Start()
    {
		health = maxhealth;
		AgentTransform = transform;		      

		agent = AgentTransform.GetComponent<NavMeshAgent>();
		obstacle = AgentTransform.GetComponent<NavMeshObstacle> ();

		destinationPosition = AgentTransform.position;	

		animator = AgentTransform.GetComponent<Animator>();
		layer = animator.GetLayerIndex(creaturekind.ToString());//layer = animator.GetLayerIndex("Base Layer");

    }

    // Update is called once per frame
    void Update()
    {
		if (Noun2go != null) 
		{
            destinationPosition = Noun2go.transform.position;
            LookAt(EnemyTransform);

            CheckStoppingDistance();
        }
        
        
        if (WalkingToPoint == true)
        {
            CheckStoppingDistance();
        }


		if (IsAttacking == true) 
		{
			if (EnemyTransform != null) 
			{
				Noun2go = EnemyTransform.gameObject;
				noun2 = Noun2go.name;

				Noun2Script = Noun2go.GetComponent<	AnimatorScript > ();
				if (Noun2Script.alive == false) 
				{
					Play ("is idle");//isidle
				}

			}

		}
    }



    void CheckStoppingDistance() 
    {
        destinationDistance = Vector3.Distance(destinationPosition, AgentTransform.position);

        if (destinationDistance < 1.5f)
        {
            if (ApproachAndAttack == true) 
            {
                agent.Stop();
                LookAt(EnemyTransform);
                PlayAttack(DestinationVerb);

            }
            else if (ApproachAndAttack == false) 
            {
                agent.Stop();

				if (animator != null) 
				{
					animator.Play("is idle", layer, 0f);
				}            

                Noun2go = null;
                noun2 = "";
                verb = "";

                WalkingToPoint = false;
            }
        } 
    }




    public void AttackTransform(string AnimationName, Transform Noun2Transform) 
    {
        ApproachAndAttack = true;
        DestinationVerb = AnimationName;

        EnemyTransform = Noun2Transform;

		Noun2go = EnemyTransform.gameObject;
		noun2 = Noun2go.name;


        LookAt(EnemyTransform);

        Goto("walks to", Noun2Transform.position);


        //animator.Play(AnimationName, layer, 0f);
    }
     

    void LookAt(Transform Noun2Transform) 
    {
        transform.LookAt(Noun2Transform);
    }


	public void Play(string AnimationName, string Noun2) 
    {
        noun2 = Noun2;

        if (AnimationName == "attacks") 
        {
            Noun2go = GameObject.Find(Noun2.ToUpper());
            AttackTransform(AnimationName, Noun2go.transform);
        }
        else if (AnimationName == "walks to")
        {
            Goto(AnimationName, Noun2);
        }
        else if (AnimationName == "runs to")
        {
            Goto(AnimationName, Noun2);
        }
        else 
        {
            animator.Play(AnimationName, layer, 0f);
        }
	      
    }


	public void Play(string AnimationName)
	{
		animator.Play(AnimationName, layer, 0f);
	}


	public void PlayAttack(string AttackAnimationName)
	{
        if (IsAttacking == false)
        {
            animator.Play(AttackAnimationName, layer, 0f);
            IsAttacking = true;
        }
        else 
        {
            LookAt(EnemyTransform);
        }    
   	}

	public void Goto(string AnimationName, string Noun2)
	{
        IsAttacking = false;
		animator.Play(AnimationName, layer, 0f);
		MovePlayerTowards (Noun2);
	}




	void MovePlayerTowards(string Noun2)
	{	
		obstacle.enabled = false;
		agent.enabled = true;


		Noun2go =GameObject.Find(Noun2.ToUpper());
        EnemyTransform = Noun2go.transform;

		destinationPosition =	Noun2go.transform.position;

        LookAt(EnemyTransform);
        IsAttacking = false;
		agent.destination = destinationPosition;
		agent.Resume();
	}


    public void Goto(string AnimationName, Vector3 position) 
    {
		if (animator != null) 
		{
			animator.Play(AnimationName, layer, 0f);
		}        
        obstacle.enabled = false;
        agent.enabled = true;
        
        destinationPosition = position;
        WalkingToPoint = true;
        IsAttacking = false;
        agent.destination = destinationPosition;
        agent.Resume();

    }

	public void ReceiveDamage(int damage)
	{
		health = health - damage;
		Debug.Log ("Health of " + this.name.ToString () + " is now: " + System.Convert.ToString (health));

		if (health <= 0)
		{
			health = 0;
			alive = false;
			Debug.Log (this.name.ToString() + " died");
			//play death animation
			//and freeze on last frame

			Rigidbody rb = this.GetComponent<Rigidbody> ();
			rb.isKinematic = false;
			rb.useGravity = true;

		}

		//play (hit) 
		//then stop

	}



	public void _TakeHealthTime()
	{
		if (EnemyTransform != null) 
		{
			Noun2go = EnemyTransform.gameObject;
			noun2 = Noun2go.name;

			Noun2Script = Noun2go.GetComponent<	AnimatorScript > ();
			Noun2Script.ReceiveDamage (10);

		}

	}

}
